Scenario failed_09: Path Traversal Entry. Archive contains a parent-directory traversal entry that must be rejected.
