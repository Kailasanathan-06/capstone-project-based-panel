Scenario loop_08: Cloud Sync Retry Storm. Cloud synchronization task simulates latency far above its timeout with five retries.
