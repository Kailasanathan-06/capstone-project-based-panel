Scenario success_06_device_telemetry_stream
Valid bedside device telemetry, diagnostic edge inference, and population health aggregate workloads across Local, MEC, and Cloud.
