Scenario failed_08: Disallowed Executable Payload. Archive contains an executable file that must be blocked by extension policy.
