Scenario loop_06: Five Node Dependency Cycle. Five tasks form a closed dependency chain spanning all three storage tiers.
