Scenario failed_06: Insufficient Resource Tiers. Manifest defines only Local and MEC resources, omitting Cloud.
