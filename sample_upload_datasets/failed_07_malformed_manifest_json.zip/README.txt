Scenario failed_07: Malformed Manifest JSON. Manifest file contains truncated JSON that cannot be parsed.
