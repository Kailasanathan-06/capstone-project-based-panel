Scenario failed_10: Decompression Expansion Limit. Archive expands beyond the 250 MB uncompressed safety limit.
