Scenario loop_10: Cycle And Timeout Mixed. A dependency cycle and a timed-out task are combined to verify cycle detection wins.
