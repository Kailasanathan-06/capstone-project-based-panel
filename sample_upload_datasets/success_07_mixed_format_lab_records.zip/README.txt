Scenario success_07_mixed_format_lab_records
Valid CSV, JSON, and TXT laboratory and clinical records with tier-appropriate privacy policies.
