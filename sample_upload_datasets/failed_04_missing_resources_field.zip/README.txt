Scenario failed_04: Missing Resources Field. Manifest intentionally omits the mandatory resources field.
