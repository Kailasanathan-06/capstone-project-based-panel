Scenario success_01_basic_all_storage
Tests standard baseline dataset upload containing valid files for Local, MEC, and Cloud resources.