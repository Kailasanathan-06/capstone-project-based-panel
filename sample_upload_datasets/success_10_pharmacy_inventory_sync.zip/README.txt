Scenario success_10: Pharmacy Inventory Sync. Valid controlled-drug ledger, cold-chain telemetry, label verification, and supply-chain aggregate workloads.
