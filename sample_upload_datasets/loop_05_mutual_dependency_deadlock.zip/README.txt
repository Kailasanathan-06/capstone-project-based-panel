Scenario loop_05: Mutual Dependency Deadlock. Two tasks wait on each other, forming a two-node deadlock cycle.
