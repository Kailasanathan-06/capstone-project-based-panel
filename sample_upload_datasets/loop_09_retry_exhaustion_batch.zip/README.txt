Scenario loop_09: Retry Exhaustion Batch. Three tasks each exceed their watchdog and exhaust a single retry.
