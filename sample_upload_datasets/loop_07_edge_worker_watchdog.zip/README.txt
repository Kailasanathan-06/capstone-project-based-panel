Scenario loop_07: Edge Worker Watchdog Timeout. Edge inference task simulates a 6-second response against a 2-second watchdog.
