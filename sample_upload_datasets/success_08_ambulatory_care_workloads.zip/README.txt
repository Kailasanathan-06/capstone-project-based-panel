Scenario success_08_ambulatory_care_workloads
Four independent ambulatory care workloads spanning Local, two MEC diagnostic batches, and Cloud administration.
