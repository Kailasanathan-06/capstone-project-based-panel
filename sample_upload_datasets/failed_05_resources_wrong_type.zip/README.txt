Scenario failed_05: Resources Wrong Type. Manifest declares resources as an object instead of the required list.
