Scenario loop_04: Self Dependency Loop. A single task declares itself as a dependency, creating a one-node cycle.
